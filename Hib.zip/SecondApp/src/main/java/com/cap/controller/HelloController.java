package com.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cap.model.User;

@Controller
public class HelloController {

	@RequestMapping("/success")
	public String success(@Validated User user, Model model) {
		
		model.addAttribute("uname",user.getUname());
		return "success";
	}
	
	
	
	@RequestMapping("/")
	public String login() {
		
		return "login";	
		
	}
}
